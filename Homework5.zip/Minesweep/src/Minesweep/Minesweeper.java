import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// code from ChatGTP
public class Minesweeper extends JFrame {
    private final int ROWS = 10;
    private final int COLS = 10;
    private final int MINES = 10;
    private JButton[][] grid;

    public Minesweeper() {
        setTitle("Minesweeper");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);

        Container container = getContentPane();
        container.setLayout(new GridLayout(ROWS, COLS));
        grid = new JButton[ROWS][COLS];

        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                JButton button = new JButton();
                button.setBackground(Color.LIGHT_GRAY);
                button.addMouseListener(new TileListener(row, col));
                container.add(button);
                grid[row][col] = button;
            }
        }

        generateMines();
        setVisible(true);
    }

    private void generateMines() {
        int count = 0;
        while (count < MINES) {
            int row = (int) (Math.random() * ROWS);
            int col = (int) (Math.random() * COLS);
            if (!grid[row][col].getText().equals("*")) {
                grid[row][col].setText("*");
                count++;
            }
        }
    }

    private class TileListener extends MouseAdapter {
        private int row;
        private int col;

        public TileListener(int row, int col) {
            this.row = row;
            this.col = col;
        }

        @Override
        public void mouseClicked(MouseEvent e) {
            JButton button = (JButton) e.getSource();
            if (SwingUtilities.isLeftMouseButton(e)) {
                if (button.getText().equals("*")) {
                    button.setBackground(Color.RED);
                    revealMines();
                    JOptionPane.showMessageDialog(null, "Game Over!");
                    System.exit(0);
                } else {
                    int minesCount = countAdjacentMines(row, col);
                    button.setText(minesCount > 0 ? String.valueOf(minesCount) : "");
                    button.setBackground(Color.WHITE);
                }
            }
        }

        private int countAdjacentMines(int row, int col) {
            int count = 0;
            for (int i = Math.max(0, row - 1); i <= Math.min(row + 1, ROWS - 1); i++) {
                for (int j = Math.max(0, col - 1); j <= Math.min(col + 1, COLS - 1); j++) {
                    if (grid[i][j].getText().equals("*")) {
                        count++;
                    }
                }
            }
            return count;
        }

        private void revealMines() {
            for (int row = 0; row < ROWS; row++) {
                for (int col = 0; col < COLS; col++) {
                    if (grid[row][col].getText().equals("*")) {
                        grid[row][col].setBackground(Color.RED);
                    }
                }
            }
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new Minesweeper());
    }
}
