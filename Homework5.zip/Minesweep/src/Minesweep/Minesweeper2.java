package Minesweep;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// Main Minesweeper2 class
public class Minesweeper2 extends JFrame {
    private static final int ROWS = 10; // Number of rows in the game board
    private static final int COLS = 10; // Number of columns in the game board
    private static final int MINES = 10; // Number of mines in the game
    private final JButton[][] grid; // 2D array to hold the game board tiles

    // Constructor
    public Minesweeper2() {
        setTitle("Minesweeper");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(400, 400);
        grid = new JButton[ROWS][COLS];
        initializeGameBoard(); // Initialize the game board
        setVisible(true);
    }

    // Method to initialize the game board
    private void initializeGameBoard() {
        Container container = getContentPane();
        container.setLayout(new GridLayout(ROWS, COLS));
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                JButton button = createButton(); // Create a button for each tile
                button.addMouseListener(new TileListener(row, col)); // Add mouse listener to handle tile clicks
                container.add(button); // Add button to the container
                grid[row][col] = button; // Add button to the grid array
            }
        }
        generateMines(); // Generate mines on the game board
    }

    // Method to create a button with default properties
    private JButton createButton() {
        JButton button = new JButton();
        button.setBackground(Color.LIGHT_GRAY); // Set button background color
        return button;
    }

    // Method to generate mines on the game board
    private void generateMines() {
        int count = 0;
        int maxAttempts = ROWS * COLS; // Maximum attempts to prevent infinite loop
        int attempts = 0;
        while (count < MINES && attempts < maxAttempts) {
            int row = (int) (Math.random() * ROWS); // Generate random row index
            int col = (int) (Math.random() * COLS); // Generate random column index
            if (grid[row][col].getText().isEmpty()) { // Check if tile is empty
                grid[row][col].setText("*"); // Place mine on the tile
                count++; // Increment mine count
            }
            attempts++; // Increment attempt count
        }
        if (count < MINES) {
            System.err.println("Error: Unable to place all mines due to lack of available empty tiles.");
            // Handle error gracefully
        }
    }

    // Method to count adjacent mines for a given tile
    private int countAdjacentMines(int row, int col) {
        int count = 0;
        for (int i = Math.max(0, row - 1); i <= Math.min(row + 1, ROWS - 1); i++) {
            for (int j = Math.max(0, col - 1); j <= Math.min(col + 1, COLS - 1); j++) {
                if (grid[i][j].getText().equals("*")) { // Check if tile is a mine
                    count++; // Increment mine count
                }
            }
        }
        return count; // Return total number of adjacent mines
    }

    // Method to reveal all mines on the game board
    private void revealMines() {
        for (int row = 0; row < ROWS; row++) {
            for (int col = 0; col < COLS; col++) {
                if (grid[row][col].getText().equals("*")) { // Check if tile is a mine
                    grid[row][col].setBackground(Color.RED); // Change tile color to red
                }
            }
        }
    }

    // Inner class representing listener for tile clicks
    private class TileListener extends MouseAdapter {
        private final int row;
        private final int col;

        // Constructor
        public TileListener(int row, int col) {
            this.row = row; // Set row index
            this.col = col; // Set column index
        }

        // Method to handle mouse clicks on tiles
        @Override
        public void mouseClicked(MouseEvent e) {
            JButton button = (JButton) e.getSource(); // Get the button that was clicked
            if (SwingUtilities.isLeftMouseButton(e)) { // Check if left mouse button was clicked
                handleLeftClick(button); // Handle left click on the button
            }
        }

        // Method to handle left mouse clicks on tiles
        private void handleLeftClick(JButton button) {
            if (button.getText().equals("*")) { // Check if tile is a mine
                button.setBackground(Color.RED); // Change tile color to red
                revealMines(); // Reveal all mines on the game board
                JOptionPane.showMessageDialog(null, "Game Over!"); // Display game over message
                System.exit(0); // Exit the game
            } else { // If tile is not a mine
                int minesCount = countAdjacentMines(row, col); // Count adjacent mines
                button.setText(minesCount > 0 ? String.valueOf(minesCount) : ""); // Set text on button
                button.setBackground(Color.WHITE); // Change tile color to white
            }
        }
    }

    // Main method to start the game
    public static void main(String[] args) {
        SwingUtilities.invokeLater(Minesweeper::new); // Start the game on the Event Dispatch Thread
    }
}
