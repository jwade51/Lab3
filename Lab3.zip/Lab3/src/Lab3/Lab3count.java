package Lab3;

public class Lab3count {

    public static int maxLength(int i, int j) {
        int start, end;

        if (i < j) {
            start = i;
            end = j;
        } else {
            start = j;
            end = i;
        }

        int maxCycle = 0;

        for (int n = start; n <= end; n++) {
            int cycleLength = getCycleLength(n);

            if (cycleLength > maxCycle) {
                maxCycle = cycleLength;
            }
        }

        return maxCycle;
    }

    private static int getCycleLength(int n) {
        int cycleLength = 1;

        while (n != 1) {
            if (n % 2 == 0) {
                n /= 2;
            } else {
                n = 3 * n + 1;
            }
            cycleLength++;
        }

        return cycleLength;
    }
}
