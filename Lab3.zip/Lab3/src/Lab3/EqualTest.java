package Lab3;

import static org.junit.Assert.*;

import org.junit.Test;

public class EqualTest {

	  @Test
	    public void testEvenStartingNumber() {
	        assertEquals(10, Lab3count.maxLength(4, 10));
	    }

	    @Test
	    public void testOddStartingNumber() {
	        assertEquals(20, Lab3count.maxLength(7, 15));
	    }
	    @Test
	    public void testSmallRange() {
	        assertEquals(9, Lab3count.maxLength(3, 6));
	    }
	    @Test
	    public void testLargeRange() {
	        assertEquals(179, Lab3count.maxLength(100, 1000));
	    }

	    @Test
	    public void testMaximumInput() {
	        assertEquals(259, Lab3count.maxLength(999999, 0));
	}

}
